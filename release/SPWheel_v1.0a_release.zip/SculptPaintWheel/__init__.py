# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


bl_info = {
    "name" : "Sculpt+Paint Wheel",
    "author" : "J. Fran Matheu (@jfranmatheu)",
    "description" : "Enhance your workflow with this awesome sculpt+paint wheel!",
    "blender" : (2, 91, 0),
    "version" : (1, 0, 0),
    "location" : "Hold 'Space' inside 3D Viewport in Sculpt/Texture/Vertex modes. // 3D Viewport > Sidebar ('N') > 'Sculpt'/'Paint' tab > 'Sculpt Wheel'/'Paint Wheel'",
    "warning" : "",
    "category" : "Interface"
}

from . import auto_load

auto_load.init()

def register():
    auto_load.register()
    from bpy.utils import register_class
    #from .icons import register as register_icons
    #register_icons()
    from .ui.ui import register as register_ui
    register_ui(register_class)

def unregister():
    from .ui.ui import unregister as unregister_ui
    from bpy.utils import unregister_class
    unregister_ui(unregister_class)
    auto_load.unregister()
    #from .icons import unregister as unregister_icons
    #unregister_icons()
