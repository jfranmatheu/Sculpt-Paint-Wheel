from bpy.types import Panel
from bl_ui.properties_paint_common import brush_settings

class SculptWheelTool_ContextMenu(Panel):
    bl_idname = "SCULPTWHEEL_PT_show_tool_context_menu"
    bl_label = "Tool Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = "NONE"

    def draw(self, context):
        toolset = context.scene.sculpt_wheel.get_active_toolset()
        if not toolset:
            return
        tool  = toolset.get_active_tool().tool
        if not tool:
            return

        brush_settings(self.layout, context, tool, True)
