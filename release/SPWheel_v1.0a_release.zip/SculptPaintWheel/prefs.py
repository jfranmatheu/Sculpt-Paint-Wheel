from bpy.types import AddonPreferences
from bpy.props import *

def get_prefs(context):
    return context.preferences.addons[__package__].preferences

class SculptWheelPreferences(AddonPreferences):
    bl_idname = __package__
    
    radius : IntProperty(min=128, default=180, max=300)
    show_tool_names : BoolProperty(default=False)
    use_custom_tool_colors : BoolProperty(default=False)
    keep_open : BoolProperty(default=False)
    custom_tool_color_mode : EnumProperty (
        items=(
            ('RING', "Outline", ""),
            ('FILL', "Background", "")
        ),
        default='RING',
        name="Custom Tool Color Mode"
    )
    on_release_select : BoolProperty(default=False, description="Select tool that is under the mouse on key release instead of by LMB clicking on it")
    gesturepad_mode : EnumProperty (
        items=(
            ('PREVIEW', "With Preview", ""),
            ('SIMPLE', "Simplified", "")
        ),
        default='PREVIEW',
        name="Gesture Pad Mode"
    )
    tool_icon_scale : FloatProperty(min=0.5, max=1.0, default=1.0, name="Tool Icon Scale")

    def draw(self, context):
        layout = self.layout
        if not isinstance(self, AddonPreferences):
            self = get_prefs(context)
            not_prefs = True
        else:
            not_prefs = False
        layout.use_property_split = True
        layout.use_property_decorate = False

        #wheel_data = scn.sculpt_wheel

        settings = layout.column(align=True)
        header = settings.box()
        header.label(text="Settings :", icon='SETTINGS')

        props = settings.box()
        props.prop(self, 'radius', text="Wheel Radius", slider=True)

        if not not_prefs or (not_prefs and context.mode == 'SCULPT'):
            props.prop(self, 'gesturepad_mode')
            
            props = settings.box()
            props.label(text="Tools :")
            props.prop(self, 'tool_icon_scale', text="Icon Scale", slider=True)
            props.prop(self, 'show_tool_names', text="Show Tool Names")
            
            col = props.column(align=True)
            col.prop(self, 'use_custom_tool_colors', text="Custom Tool Color")
            row = col.row()
            row.enabled = self.use_custom_tool_colors
            row.prop(self, 'custom_tool_color_mode', text='')

        # kmi = context.window_manager.keyconfigs.addon.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        if not_prefs:
            from . km import get_keyitem
            kmi = get_keyitem(context)
            if kmi:
                box = settings.box()
                box.label(text="Keymap :")
                row = box.row()
                row.label(text="Press Key")
                row.template_event_from_keymap_item(kmi)
                row = box.row(align=True)
                row.prop(kmi, 'map_type', text="")
                row.prop(kmi, 'type', text="")
        else:
            from . km import get_keyitem_mode, modes
            for mode in modes:
                kmi = get_keyitem_mode(context, mode)
                if kmi:
                    box = settings.box()
                    box.label(text=mode + " keymap :")
                    row = box.row()
                    row.label(text="Press Key")
                    row.template_event_from_keymap_item(kmi)
                    row = box.row(align=True)
                    row.prop(kmi, 'map_type', text="")
                    row.prop(kmi, 'type', text="")
        box = settings.box()
        box.label(text="Other Settings:")
        if not not_prefs or (not_prefs and context.mode == 'SCULPT'):
            box.prop(self, 'on_release_select', text="Select Tool On Release")
        box.prop(self, 'keep_open', text="Press Again to Close")
        
        '''
        layout = self.layout
        #kmi = context.window_manager.keyconfigs.addon.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        kmi = context.window_manager.keyconfigs.user.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        if kmi:
            box = layout.box()
            box.label(text="Keymap :")
            row = box.row()
            row = box.row(align=True)
            row.alignment = 'LEFT'
            row.label(text="Press Key")
            row.template_event_from_keymap_item(kmi)
            row = box.row()
            row.prop(kmi, 'map_type', text="")
            row.prop(kmi, 'type', text="")
        '''
        
        
        '''
        keyconfing = context.window_manager.keyconfigs.user    
        keymap = keyconfing.keymaps['Sculpt']
        kmi = keymap.keymap_items.get('sculpt.wheel', None)
        if kmi:
            layout.template_event_from_keymap_item(kmi)
            layout.template_keymap_item_properties(kmi)
        '''
