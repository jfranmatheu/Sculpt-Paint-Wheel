from . sculpt.data import SculptWheelData
from . weight.data import WeightWheelData

def register():
    from bpy.props import PointerProperty, IntProperty
    from bpy.types import Scene as scn, Brush
    scn.sculpt_wheel = PointerProperty(type=SculptWheelData)
    scn.weight_wheel = PointerProperty(type=WeightWheelData)
    Brush.toolset_id = IntProperty(default=-1)

def unregister():
    from bpy.types import Scene as scn, Brush
    del scn.sculpt_wheel
    del scn.weight_wheel
    del Brush.toolset_id
