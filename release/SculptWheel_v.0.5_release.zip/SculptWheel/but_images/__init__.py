from enum import Enum
from ..fun import load_image
PNG = '.png'
JPG = '.jpg'
BUT_IMAGE = 'but_images'


class Icon(Enum):
    EDIT = '.Edit'

    def __call__(self):
        return load_image(self.value, PNG, BUT_IMAGE)

def load_icon(icon):
    ico = icon()
    if ico:
        ico.gl_load()
        return ico, ico.bindcode
    return None
