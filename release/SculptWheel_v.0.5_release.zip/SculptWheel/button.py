from .fun import point_inside_circle
from .dibuix import DiCFCL, DiIMGAMMA


class ButtonCircle:
    def __init__(self, pos, rad, co, i, fun, *args):
        self.pos = pos
        self.rad = rad
        self.co = co
        self.id = i
        self.fun = fun
        self.args = args
        self.on_hover = False

    def check(self, mouse):
        self.on_hover = point_inside_circle(mouse, self.pos, self.rad)
        return self.on_hover

    def __call__(self):
        if self.args:
            self.fun(self.args)
        else:
            self.fun()

    def draw(self):
        if self.on_hover:
            DiCFCL(self.pos, self.rad, self.co, (0, 1, 1, .9))
        else:
            DiCFCL(self.pos, self.rad, self.co, (.4, .4, .4, .9))
        if self.id:
            rad = self.rad*.7
            DiIMGAMMA((self.pos[0]-rad, self.pos[1]-rad), [rad*2]*2, self.id)
