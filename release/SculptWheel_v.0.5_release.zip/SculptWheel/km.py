def register():
    from bpy import context as C
    cfg = C.window_manager.keyconfigs.addon
    if not cfg.keymaps.__contains__('Sculpt'):
        cfg.keymaps.new('Sculpt', space_type='EMPTY', region_type='WINDOW')
    kmi = cfg.keymaps['Sculpt'].keymap_items
    kmi.new('sculpt.wheel', 'SPACE', 'PRESS')


def unregister():
    from bpy import context as C
    cfg = C.window_manager.keyconfigs.addon
    if cfg.keymaps.__contains__('Sculpt'):
        for kmi in cfg.keymaps['Sculpt'].keymap_items:
            if kmi.idname == 'sculpt.wheel':
                if kmi.value == 'PRESS' and kmi.type == 'SPACE':
                    cfg.keymaps['Sculpt'].keymap_items.remove(kmi)
                    break
