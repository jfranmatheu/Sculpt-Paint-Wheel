from bpy.types import AddonPreferences

class SculptWheelPreferences(AddonPreferences):
    bl_idname = 'SculptWheel'

    def draw(self, context):
        layout = self.layout
        #kmi = context.window_manager.keyconfigs.addon.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        kmi = context.window_manager.keyconfigs.user.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        if kmi:
            box = layout.box()
            box.label(text="Keymap :")
            row = box.row()
            row = box.row(align=True)
            row.alignment = 'LEFT'
            row.label(text="Press Key")
            row.template_event_from_keymap_item(kmi)
            row = box.row()
            row.prop(kmi, 'map_type', text="")
            row.prop(kmi, 'type', text="")
        
        '''
        keyconfing = context.window_manager.keyconfigs.user    
        keymap = keyconfing.keymaps['Sculpt']
        kmi = keymap.keymap_items.get('sculpt.wheel', None)
        if kmi:
            layout.template_event_from_keymap_item(kmi)
            layout.template_keymap_item_properties(kmi)
        '''
