from bpy.types import Panel, UILayout # SCULPT_PT_Wheel
# from .. panel import SculptWheelPanel

'''
class SculptWheelBasePanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ".paint_common"
    bl_category = 'Sculpt'
'''

class SculptWheelPanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ".paint_common"
    bl_category = 'Sculpt'

    bl_idname = "SCULPT_PT_wheel"
    bl_label = "Sculpt Wheel"

    @classmethod
    def poll(cls, context):
        return context.mode == 'SCULPT'

    def draw(self, context):
        pass

class SculptWheelToolsets(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ".paint_common"
    bl_category = 'Sculpt'

    bl_parent_id = 'SCULPT_PT_wheel'
    bl_label = 'Toolsets'
    bl_idname = "SCULPT_PT_wheel_toolsets"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1

    def draw(self, context):
        scn = context.scene
        layout = self.layout

        wheel_data = scn.sculpt_wheel

        if wheel_data.active_toolset == -1:
            layout.label(text="Create a toolset to start:")
            layout.operator('sculpt.wheel_add_toolset', text="Create Toolset")
            return

        active_toolset = wheel_data.get_active_toolset()

        box = layout.box()
        grid = box.grid_flow(row_major=True, even_columns=True, align=True, columns=3)
        for i, toolset in enumerate(wheel_data.toolsets):
            grid.operator('sculpt.wheel_activate_toolset', text=toolset.name, depress=toolset == active_toolset).index = i

        _box = box.box()
        _row = _box.row(align=True)
        _row.prop(active_toolset, 'name')
        _row.operator('sculpt.wheel_remove_active_toolset', text="", icon='TRASH')
        
        toolbox = _box.box().column(align=True)
        #i = 0
        if wheel_data.use_custom_tool_colors:
            for tool in active_toolset.tools:
                row = toolbox.row(align=True)
                _row = row.row(align=True)
                _row.ui_units_x = .75
                _row.prop(tool, 'color', text="")
                if tool.idname:
                    row.prop(tool, 'name', text="")
                    #row.operator('sculpt.wheel_remove_tool', text="", icon='X').index = i
                else:
                    row.prop(tool, 'tool', text="", icon_value=UILayout.icon(tool.tool))
                #i += 1
        else:
            for tool in active_toolset.tools:
                if tool.idname:
                    row = toolbox.row(align=True)
                    row.use_property_decorate = True
                    row.prop(tool, 'name', text="")
                    #row.operator('sculpt.wheel_remove_tool', text="", icon='X').index = i
                else:
                    toolbox.prop(tool, 'tool', text="", icon_value=UILayout.icon(tool.tool))
                #i += 1

        row = _box.row()
        row.alignment = 'RIGHT'
        row.operator('sculpt.wheel_add_active_tool', text="Add Active Brush", icon='ADD')

        box.operator('sculpt.wheel_add_toolset', text="New ToolSet", icon='COLLECTION_NEW')
        
        box = layout.box()
        box.operator('sculpt.wheel_load_default_tools', text="Reset to default")


class SculptWheelCustomButtons(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ".paint_common"
    bl_category = 'Sculpt'

    bl_parent_id = 'SCULPT_PT_wheel'
    bl_label = 'Custom Buttons'
    bl_idname = "SCULPT_PT_wheel_custom_buttons"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2

    def draw(self, context):
        scn = context.scene
        layout = self.layout

        wheel_data = scn.sculpt_wheel
        create = wheel_data.create_custom_button
        buttons = wheel_data.custom_buttons

        if len(buttons) != 0:
            box = layout.box().column(align=True)
            box.use_property_split = True
            box.use_property_decorate = False
            box.label(text="List :", icon="OUTLINER")
            box.separator()
        for i, b in enumerate(buttons):
            row = box.row(align=True)
            # row.prop(b, 'show_settings', text="", icon='TRIA_RIGHT' if not b.show_settings else 'TRIA_DOWN')
            row.prop(b, 'name', text="")
            row.operator('sculpt.wheel_remove_custom_button', text="", icon="X").index = i
            if b.show_settings:
                sett = box.box()
                sett.prop(b, 'image_path', text="Image Path")
                #sett.template_icon_view(context.window_manager, "sculpt_wheel_icons")
                sett.prop(b, 'type', text="Type")
                if b.type == 'POPUP':
                    sett.prop(b, 'popup_type', text="Pop-up Type")
                    _row = sett.row()
                    _row.prop(b, 'as_attribute', text="Use...", expand=True)
                    if b.as_attribute == 'PRESET':
                        if b.popup_type == 'MENU':
                            sett.prop(b, 'preset_menu', text="Presets")
                        elif b.popup_type == 'PANEL':
                            sett.prop(b, 'preset_panel', text="Presets")
                        elif b.popup_type == 'PIE_MENU':
                            # sett.prop(b, 'popup_type', text="Identifier") # TODO: Some presets for pie menus?
                            sett.alert = True
                            sett.label(text="No presets for pie menus :(")
                    elif b.as_attribute == 'CUSTOM':
                        sett.prop(b, 'custom_identifier', text="Idname")
                elif b.type == 'OPERATOR':
                    _row = sett.row()
                    _row.prop(b, 'as_attribute', text="Use...", expand=True)
                    if b.as_attribute == 'PRESET':
                        sett.prop(b, 'preset_operator', text="Presets")
                    elif b.as_attribute == 'CUSTOM':
                        sett.prop(b, 'custom_identifier', text="Operator")
                        sett.label(text="Example: bpy.ops.object.voxel_remesh()")
                elif b.type == 'TOGGLE':
                    sett.alert = True
                    sett.label(text="Work in progress...")

                    #_row = sett.row()
                    #_row.prop(create, 'as_attribute', text="Use...", expand=True)
                    #if create.as_attribute == 'PRESET':
                    #    sett.label(text="No presets for toggles :(")
                    #elif create.as_attribute == 'CUSTOM':
                    #    sett.prop(create, 'custom_identifier', text="Property Name")

                box.separator()

        box = layout.box().column(align=True)
        box.use_property_split = True
        box.use_property_decorate = False
        box.label(text="Create :", icon="PROPERTIES")
        box.separator()
        sett = box.box()
        sett.prop(create, 'name', text="Name")
        sett.prop(create, 'image_path', text="Image Path")
        #sett.template_icon_view(context.window_manager, "sculpt_wheel_icons")
        sett.prop(create, 'type', text="Type")
        if create.type == 'POPUP':
            sett.prop(create, 'popup_type', text="Pop-up Type")
            _row = sett.row()
            _row.prop(create, 'as_attribute', text="Use...", expand=True)
            if create.as_attribute == 'PRESET':
                if create.popup_type == 'MENU':
                    sett.prop(create, 'preset_menu', text="Presets")
                elif create.popup_type == 'PANEL':
                    sett.prop(create, 'preset_panel', text="Presets")
                elif create.popup_type == 'PIE_MENU':
                    # sett.prop(b, 'popup_type', text="Identifier") # TODO: Some presets for pie menus?
                    sett.alert = True
                    sett.label(text="No presets for pie menus :(")
            elif create.as_attribute == 'CUSTOM':
                sett.prop(create, 'custom_identifier', text="Idname")
        elif create.type == 'OPERATOR':
            _row = sett.row()
            _row.prop(create, 'as_attribute', text="Use...", expand=True)
            if create.as_attribute == 'PRESET':
                sett.prop(create, 'preset_operator', text="Presets")
            elif create.as_attribute == 'CUSTOM':
                sett.prop(create, 'custom_identifier', text="Operator")
                sett.label(text="Example: bpy.ops.object.voxel_remesh()")
        elif create.type == 'TOGGLE':
            sett.alert = True
            sett.label(text="Work in progress...")

            #_row = sett.row()
            #_row.prop(create, 'as_attribute', text="Use...", expand=True)
            #if create.as_attribute == 'PRESET':
            #    sett.label(text="No presets for toggles :(")
            #elif create.as_attribute == 'CUSTOM':
            #    sett.prop(create, 'custom_identifier', text="Property Name")

        box.operator('sculpt.wheel_add_custom_button', text="Create Button")
        
        box = layout.box()
        box.operator('sculpt.wheel_load_default_custom_buttons', text="Reset to default")


class SculptWheelSettings(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ".paint_common"
    bl_category = 'Sculpt'

    bl_parent_id = 'SCULPT_PT_wheel'
    bl_label = 'Wheel Settings'
    bl_idname = "SCULPT_PT_wheel_settings"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 3

    def draw(self, context):
        scn = context.scene
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        wheel_data = scn.sculpt_wheel

        settings = layout.column(align=True)
        header = settings.box()
        header.label(text="Settings :", icon='SETTINGS')

        props = settings.box()
        props.prop(wheel_data, 'radius', text="Wheel Radius", slider=True)

        props.prop(wheel_data, 'gesturepad_mode')
        
        props = settings.box()
        props.label(text="Tools :")
        props.prop(wheel_data, 'show_tool_names', text="Show Tool Names")
        
        col = props.column(align=True)
        col.prop(wheel_data, 'use_custom_tool_colors', text="Custom Tool Color")
        row = col.row()
        row.enabled = wheel_data.use_custom_tool_colors
        row.prop(wheel_data, 'custom_tool_color_mode', text='')

        # kmi = context.window_manager.keyconfigs.addon.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        kmi = context.window_manager.keyconfigs.user.keymaps['Sculpt'].keymap_items.get('sculpt.wheel', None)
        if kmi:
            box = settings.box()
            box.label(text="Keymap :")
            row = box.row()
            row.label(text="Press Key")
            row.template_event_from_keymap_item(kmi)
            row = box.row(align=True)
            row.prop(kmi, 'map_type', text="")
            row.prop(kmi, 'type', text="")
            box.prop(wheel_data, 'on_release_select', text="Select Tool On Release")
            box.prop(wheel_data, 'keep_open', text="Press Again to Close")
        

classes = (
    SculptWheelPanel,
    SculptWheelToolsets,
    SculptWheelCustomButtons,
    SculptWheelSettings
)

def register(reg):
    for cls in classes:
        reg(cls)

def unregister(unreg):
    for cls in reversed(classes):
        unreg(cls)
